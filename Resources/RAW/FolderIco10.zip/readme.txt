Installation

Unzip the package you`ve downloaded and install the software by running Setup.exe,
then run the activation program Activate.exe which is included in the package to register your copy.

NB: if you are a Vista OS user you will probably need to run Setup.exe and Activate.exe in the name of administrator on the PC.


You have to install and activate it before the Giveaway offer for the software is over.


Terms and conditions

Please note that the software you download and install during
the Giveaway period comes with the following important limitations:
1) No free technical support
2) No free upgrades to future versions
3) Strictly non-commercial usage


!!! .GCD file included is necessary for correct installation and activation. Please make sure to extract all enclosed files to the same folder. After successful activation and installation you may safely delete GOTD installation files from your PC (including .GCD)!!!
